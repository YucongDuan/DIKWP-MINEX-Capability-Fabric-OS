# DIKWP MINEX Capability Fabric OS v1.0.0 — Delivery Guide

## 中文

MINEX 将“先打开哪个 App”重构为“为了得到这个结果，哪条被授权、可验证、可纠错的能力路径耗费最低”。

它在以下执行表面之间路由：模型直接完成、本地代码、本地 API、GUI、同主体远程节点、付费能力、人类协作、已验证配方。

最短使用路径：

1. 双击 `01_DIRECT_APPLICATION/DIKWP_MINEX_CAPABILITY_FABRIC_OS_v1.0.0.html`。
2. 查看内置示例、授权范围、硬约束和 Pareto 路径。
3. 使用 `02_OPEN_SOURCE/DIKWP_MINEX_CAPABILITY_FABRIC_OS_v1.0.0.pyz` 运行完整本地演示。
4. 阅读 `03_REPORTS_CN_EN` 中的中英文系统报告。
5. 用 `04_STANDARDIZATION/MINEX_1000_STANDARDIZATION_PACK_v1.0.0.zip` 检查协议、Schema、形式模型与互操作结构。

现实边界：本版本不会真实控制 GUI、调用外部提供商、付款、签约或发布。所有物理能耗值在没有硬件或提供商测量收据时均为声明/建模值。

## English

MINEX replaces “which app should I open?” with “which authorized, verifiable, correctable capability route reaches the intended outcome with the lowest declared execution expenditure?”

It routes across model-native execution, local code, formal APIs, GUIs, same-owner peer nodes, paid capability providers, named human delegates, and verified reusable recipes.

Quick start:

1. Open `01_DIRECT_APPLICATION/DIKWP_MINEX_CAPABILITY_FABRIC_OS_v1.0.0.html`.
2. Inspect the demo intent, granted scopes, hard constraints, Pareto routes, and rejection reasons.
3. Run `02_OPEN_SOURCE/DIKWP_MINEX_CAPABILITY_FABRIC_OS_v1.0.0.pyz` for the complete local demonstration.
4. Read the Chinese and English reports under `03_REPORTS_CN_EN`.
5. Review the protocol, schemas, formal model, and interoperability assets in `04_STANDARDIZATION/MINEX_1000_STANDARDIZATION_PACK_v1.0.0.zip`.

Reality boundary: this release does not control a real GUI, invoke external providers, transfer money, enter contracts, or publish remotely. Physical-energy values remain declared or modeled unless a hardware or provider measurement receipt is attached.
